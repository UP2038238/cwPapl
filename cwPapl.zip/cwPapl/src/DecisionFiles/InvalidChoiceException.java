package DecisionFiles;

public class InvalidChoiceException extends Exception{

    public InvalidChoiceException(String s){

        super(s);
    }

}


