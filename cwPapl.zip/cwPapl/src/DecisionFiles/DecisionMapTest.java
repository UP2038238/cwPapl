package DecisionFiles;

import java.io.FileNotFoundException;
import FrontEnd.GUILayout;

public class DecisionMapTest {

    public static void main(String[] args) throws FileNotFoundException {

        GUILayout gui = new GUILayout();
        gui.EventRuntime();
    }

}
